package com.example.hush

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Houdt het afspelen levend als het scherm uit gaat, en beheert de slaaptimer. */
class PlaybackService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.hush.STOP"
        private const val CHANNEL = "playback"
        private const val NOTIF_ID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var timerWatch: Job? = null
    private var timerJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            SoundEngine.stop(1.2f)
            if (!SoundEngine.playing.value) stopSelf()
        } else {
            startPlayback()
        }
        return START_NOT_STICKY
    }

    private fun startPlayback() {
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        SoundEngine.start()
        if (watcher?.isActive == true) return

        watcher = scope.launch {
            SoundEngine.playing.first { !it }
            timerWatch?.cancel()
            timerJob?.cancel()
            SoundEngine.updateRemaining(0)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        timerWatch = scope.launch {
            SoundEngine.timerMinutes.collect { restartTimer(it) }
        }
    }

    private fun restartTimer(minutes: Int) {
        timerJob?.cancel()
        if (minutes <= 0) {
            SoundEngine.updateRemaining(0)
            return
        }
        val end = SystemClock.elapsedRealtime() + minutes * 60_000L
        timerJob = scope.launch {
            while (true) {
                val left = ((end - SystemClock.elapsedRealtime() + 999) / 1000).toInt()
                if (left <= 0) break
                SoundEngine.updateRemaining(left)
                delay(500)
            }
            SoundEngine.updateRemaining(0)
            SoundEngine.stop(10f)
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, PlaybackService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, getString(R.string.notif_stop), stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        SoundEngine.stop(0.1f)
        super.onDestroy()
    }
}

package com.example.hush

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs
import kotlin.math.max

private class Voice(val gen: Gen) {
    @Volatile var target = 0f
    var gain = 0f
}

/** Mengt alle actieve geluiden live en streamt ze naar een AudioTrack. */
object SoundEngine {
    private const val SR = 44100

    private val voices: Map<Sound, Voice> = Sound.entries.associateWith { Voice(it.factory()) }

    private val _levels = MutableStateFlow(Sound.entries.associateWith { 0f })
    val levels: StateFlow<Map<Sound, Float>> = _levels.asStateFlow()

    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing.asStateFlow()

    private val _timerMinutes = MutableStateFlow(0)
    val timerMinutes: StateFlow<Int> = _timerMinutes.asStateFlow()

    private val _remainingSec = MutableStateFlow(0)
    val remainingSec: StateFlow<Int> = _remainingSec.asStateFlow()

    @Volatile private var running = false
    @Volatile private var fadeSeconds = 0f

    fun setLevel(sound: Sound, level: Float) {
        voices.getValue(sound).target = level
        _levels.update { it + (sound to level) }
    }

    fun setTimer(minutes: Int) { _timerMinutes.value = minutes }

    fun updateRemaining(sec: Int) { _remainingSec.value = sec }

    @Synchronized
    fun start() {
        if (running) { fadeSeconds = 0f; return }
        running = true
        fadeSeconds = 0f
        _playing.value = true
        Thread({ loop() }, "hush-audio").apply { priority = Thread.MAX_PRIORITY }.start()
    }

    fun stop(fadeSec: Float) {
        if (running) fadeSeconds = max(fadeSec, 0.05f)
    }

    private fun loop() {
        val minBuf = AudioTrack.getMinBufferSize(
            SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, 16384))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val buf = ShortArray(1024)
        var master = 0f
        voices.values.forEach { it.gain = 0f }
        try {
            track.play()
            while (true) {
                val active = voices.values.filter { it.target > 0f || it.gain > 0.001f }
                val fade = fadeSeconds
                val step = if (fade > 0f) -1f / (SR * fade) else 1f / (SR * 0.4f)
                for (i in buf.indices) {
                    var s = 0f
                    for (v in active) {
                        v.gain += (v.target - v.gain) * 0.0006f
                        s += v.gen.next() * v.gain
                    }
                    master += step
                    if (master > 1f) master = 1f else if (master < 0f) master = 0f
                    val o = s * 1.4f
                    buf[i] = (o / (1f + abs(o)) * master * 32767f).toInt().toShort()
                }
                if (track.write(buf, 0, buf.size) < 0) break
                if (fade > 0f && master <= 0f) break
            }
        } finally {
            runCatching { track.stop() }
            track.release()
            synchronized(this) { running = false }
            _playing.value = false
        }
    }
}

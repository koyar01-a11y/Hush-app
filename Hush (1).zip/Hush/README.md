# Hush – slaap- en focusgeluiden (Android)

Een app die zichzelf draaiende houdt: geen server, geen account, geen audiobestanden, geen support-inbox.
Alle geluiden (regen, golven, wind, haardvuur, ruiskleuren…) worden live in code gegenereerd.
Verdienmodel: gratis (3 geluiden, één tegelijk, timer tot 60 min) + Pro-abonnement (alle geluiden, mixen, timers tot 8 uur).
Talen: Engels, Nederlands, Frans, Duits.

## 1. Eerste keer draaien
1. Android Studio (nieuwste stabiele versie) → Open → map `Hush`. Laat Gradle syncen (accepteer eventuele upgrade-suggesties van de AGP Upgrade Assistant).
2. Kies je telefoon of een emulator → Run.
3. LUISTER ZELF: de geluiden zijn berekend, niet afgeluisterd. Klinkt iets te hard/zacht of te schel? Pas de vermenigvuldigers in `Sounds.kt` aan (bijv. `* 0.55f` bij RainGen of `* 5f` bij WindGen).
4. Pas aan: `applicationId` (app/build.gradle.kts), naam (strings.xml), icoon (res/drawable/ic_launcher_foreground.xml).

## 2. Play Console (eenmalig, ca. 2 uur)
1. Ontwikkelaarsaccount ($25 eenmalig, identiteitsverificatie). Nieuwe persoonlijke accounts moeten meestal eerst een gesloten test draaien (rond 12 testers, 14 dagen) voor je live mag; controleer de actuele eis in de Console.
2. App aanmaken → App Bundle uploaden (Build > Generate Signed App Bundle). Bewaar je keystore op meerdere plekken!
3. Abonnementen → product-ID `hush_pro` → twee base plans: `monthly` en `yearly` (bijv. EUR 2,99 / EUR 19,99). Voeg bij `yearly` een aanbieding met 7 dagen gratis proefperiode toe. Activeer beide.
4. Gegevensveiligheid: "geen gegevens verzameld of gedeeld". Privacybeleid: zie `store/privacy_policy.md` (host gratis via GitHub Pages en plak de URL).
5. Inhoudsclassificatie invullen (geen gevoelige inhoud); geen kinderfocus.
6. Winkelvermelding: plak teksten uit `store/store_listing.md` (EN/NL/FR/DE). Maak 4-6 schermafbeeldingen vanaf je telefoon.

## 3. Wat autonoom loopt en wat niet
Autonoom: geluid, betalingen, abonnementsverlenging, herstel van aankopen, verwerking door Google. Geen server die kan uitvallen, geen gebruikersdata die beheerd moet worden.
Niet autonoom (eenmalig of af en toe): opzetten van de Console, schermafbeeldingen, jaarlijks de targetSdk/Billing-versie bijwerken (Google eist dat elk jaar rond 31 augustus), reageren op slechte reviews (optioneel, helpt wel).
Onderhoudsroutine: 15 minuten per maand in de Console: installs, proefperiode-conversie, opzeggingen, reviews.

## 4. Groeiplan (de enige echte onzekerheid)
Zonder bezoekers geen omzet. Gratis kanalen, in volgorde van belang:
1. Zoekwoorden (ASO): "slaapgeluiden", "witte ruis", "regengeluiden", "sleep sounds", "white noise", "baby sleep". Zet ze in titel, korte en lange beschrijving, per taal.
2. Meer talen: voeg `values-es`, `values-pt`, `values-it`, `values-pl`... toe (strings laten vertalen) en maak per taal een winkelvermelding. Slaapapps verkopen overal.
3. Scherpe screenshots met tekst ("Slaap beter met 9 geluiden").
4. Korte video's (TikTok/Reels/Shorts) met rustige beelden + link; plan er een reeks vooruit.
5. Betaalde test, pas als gratis installs bestaan: EUR 5 per dag, 7 dagen. Stop als kosten per Pro-abonnee boven ~EUR 15 uitkomen (rekening houdend met de Google-commissie op abonnementen).

## 5. Eerlijke verwachting
Dit is een drukke categorie. Er is geen garantie: veel apps verdienen weinig. Maar de kosten zijn bijna nul, onderhoud is minimaal, en elke extra taal of verbetering kost weinig. Meet na 8 weken en beslis dan: uitbreiden, bijsturen of stoppen.

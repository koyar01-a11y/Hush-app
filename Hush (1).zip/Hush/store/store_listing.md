# Store listing (kopieer per taal)

## English
Title (max 30): Hush: Sleep & Focus Sounds
Short (max 80): Sleep sounds, white noise & rain. Mix freely, sleep timer, fully offline.
Full:
Fall asleep faster and stay focused with Hush. Pick calming sounds like rain, ocean waves, wind, fireplace, a gentle stream or a fan, and blend them into your own soundscape.

• Rain, brown noise and white noise are free
• Pro: ocean, fireplace, wind, stream, fan and pink noise
• Mix as many sounds as you like (Pro)
• Sleep timer with smooth fade-out
• Keeps playing with the screen off
• Works completely offline. No account, no ads, no tracking

Perfect for sleeping, naps, babies, studying, working, meditation or blocking out noise.

## Nederlands
Titel: Hush: Slaap- & Focusgeluiden
Kort: Slaapgeluiden, witte ruis & regen. Meng vrij, slaaptimer, werkt offline.
Lang:
Val sneller in slaap en blijf gefocust met Hush. Kies rustgevende geluiden zoals regen, zeegolven, wind, haardvuur, een beekje of een ventilator en meng ze tot je eigen geluidslandschap.

• Regen, bruine ruis en witte ruis gratis
• Pro: zeegolven, haardvuur, wind, beek, ventilator en roze ruis
• Meng zoveel geluiden als je wilt (Pro)
• Slaaptimer met zacht uitfaden
• Blijft spelen met het scherm uit
• Werkt volledig offline. Geen account, geen advertenties, geen tracking

Ideaal om te slapen, een dutje te doen, baby's te kalmeren, te studeren, te werken of te mediteren.

## Français
Titre: Hush : sons pour dormir
Court: Sons pour dormir, bruit blanc, pluie. Mixez, minuteur, 100 % hors ligne.
Long:
Endormez-vous plus vite et restez concentré avec Hush. Choisissez des sons apaisants (pluie, vagues, vent, cheminée, ruisseau, ventilateur) et mélangez-les pour créer votre ambiance.

• Pluie, bruit brun et bruit blanc gratuits
• Pro : vagues, cheminée, vent, ruisseau, ventilateur, bruit rose
• Mixez autant de sons que vous voulez (Pro)
• Minuteur de sommeil avec fondu en douceur
• Continue avec l'écran éteint
• 100 % hors ligne. Sans compte, sans publicité, sans suivi

## Deutsch
Titel: Hush: Schlaf- & Fokusklänge
Kurz: Schlafklänge, weißes Rauschen & Regen. Mixen, Timer, komplett offline.
Lang:
Schlafe schneller ein und bleibe konzentriert mit Hush. Wähle beruhigende Klänge wie Regen, Meereswellen, Wind, Kaminfeuer, Bach oder Ventilator und mische sie zu deiner eigenen Klanglandschaft.

• Regen, braunes und weißes Rauschen kostenlos
• Pro: Meereswellen, Kaminfeuer, Wind, Bach, Ventilator, rosa Rauschen
• Beliebig viele Klänge mischen (Pro)
• Schlaf-Timer mit sanftem Ausblenden
• Läuft weiter bei ausgeschaltetem Bildschirm
• Komplett offline. Kein Konto, keine Werbung, kein Tracking

## Zoekwoorden-ideeën (verwerk natuurlijk in de tekst)
sleep sounds, white noise, rain sounds, baby sleep, nature sounds, focus sounds, brown noise, slaapgeluiden, witte ruis, regengeluiden, bruit blanc, sons pour dormir, weißes Rauschen, einschlafen

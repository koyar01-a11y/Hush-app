package com.example.hush

import androidx.annotation.StringRes
import kotlin.math.abs
import kotlin.math.sin

private const val SR = 44100f
private const val TWO_PI = 6.2831855f

/** Snelle, allocatievrije ruisgenerator (xorshift32). Geeft waarden tussen -1 en 1. */
class Rng(seed: Int) {
    private var s = (System.nanoTime().toInt() xor (seed * 0x9E3779B1.toInt())) or 1
    fun next(): Float {
        s = s xor (s shl 13)
        s = s xor (s ushr 17)
        s = s xor (s shl 5)
        return s * 4.656613e-10f
    }
}

interface Gen {
    fun next(): Float
}

class WhiteGen : Gen {
    private val r = Rng(1)
    override fun next() = r.next() * 0.35f
}

class PinkGen(seed: Int = 2) : Gen {
    private val r = Rng(seed)
    private var b0 = 0f
    private var b1 = 0f
    private var b2 = 0f
    override fun next(): Float {
        val w = r.next()
        b0 = 0.99765f * b0 + w * 0.0990460f
        b1 = 0.96300f * b1 + w * 0.2965164f
        b2 = 0.57000f * b2 + w * 1.0526913f
        return (b0 + b1 + b2 + w * 0.1848f) * 0.22f
    }
}

class BrownGen(seed: Int = 3) : Gen {
    private val r = Rng(seed)
    private var last = 0f
    override fun next(): Float {
        last = (last + 0.02f * r.next()) / 1.02f
        return (last * 3.5f).coerceIn(-1f, 1f)
    }
}

class RainGen : Gen {
    private val r = Rng(4)
    private val pink = PinkGen(5)
    private var hp = 0f
    private var prev = 0f
    private var drop = 0f
    override fun next(): Float {
        val w = r.next()
        hp = 0.92f * (hp + w - prev)
        prev = w
        if ((r.next() + 1f) * 0.5f < 0.0006f) drop = maxOf(drop, 0.25f + (r.next() + 1f) * 0.25f)
        val d = drop * r.next()
        drop *= 0.994f
        return hp * 0.16f + pink.next() * 0.55f + d * 0.5f
    }
}

class OceanGen : Gen {
    private val r = Rng(6)
    private val brown = BrownGen(7)
    private val pink = PinkGen(8)
    private var phase = 0f
    private var inc = 0f
    private var foam = 0f
    init { newPeriod() }
    private fun newPeriod() { inc = 1f / (SR * (6f + 5f * abs(r.next()))) }
    override fun next(): Float {
        phase += inc
        if (phase >= 1f) { phase -= 1f; newPeriod() }
        val hump = sin(3.1415927f * phase)
        val swell = hump * hump
        foam += 0.05f * (pink.next() - foam)
        return brown.next() * (0.25f + 0.75f * swell) * 1.6f + foam * swell * swell * 2f
    }
}

class WindGen : Gen {
    private val pink = PinkGen(9)
    private var l1 = 0f
    private var l2 = 0f
    private var lp = 0f
    override fun next(): Float {
        l1 += 1f / (SR * 13f); if (l1 >= 1f) l1 -= 1f
        l2 += 1f / (SR * 7.3f); if (l2 >= 1f) l2 -= 1f
        val g = 0.35f + 0.65f * (0.5f + 0.25f * sin(TWO_PI * l1) + 0.25f * sin(TWO_PI * l2))
        lp += (0.01f + 0.05f * g) * (pink.next() - lp)
        return lp * g * 5f
    }
}

class FanGen : Gen {
    private val brown = BrownGen(10)
    private val pink = PinkGen(11)
    private var p1 = 0f
    private var p2 = 0f
    private var p3 = 0f
    override fun next(): Float {
        p1 += 110f / SR; if (p1 >= 1f) p1 -= 1f
        p2 += 220f / SR; if (p2 >= 1f) p2 -= 1f
        p3 += 330f / SR; if (p3 >= 1f) p3 -= 1f
        val hum = sin(TWO_PI * p1) * 0.04f + sin(TWO_PI * p2) * 0.02f + sin(TWO_PI * p3) * 0.01f
        return brown.next() * 0.5f + pink.next() * 0.5f + hum
    }
}

class StreamGen : Gen {
    private val r = Rng(12)
    private val pink = PinkGen(13)
    private var hp = 0f
    private var prev = 0f
    private var jit = 0f
    override fun next(): Float {
        val w = r.next()
        hp = 0.85f * (hp + w - prev)
        prev = w
        jit += 0.002f * (r.next() - jit)
        val m = (0.7f + jit * 15f).coerceIn(0.2f, 1.3f)
        return hp * 0.2f * m + pink.next() * 0.35f
    }
}

class FireGen : Gen {
    private val r = Rng(14)
    private val brown = BrownGen(15)
    private val pink = PinkGen(16)
    private var crack = 0f
    override fun next(): Float {
        if ((r.next() + 1f) * 0.5f < 0.00025f) crack = 0.3f + 0.5f * abs(r.next())
        val c = crack * r.next()
        crack *= 0.985f
        return brown.next() * 0.6f + pink.next() * 0.15f + c
    }
}

/** Gratis geluiden staan bovenaan. Alle geluiden worden live gegenereerd: geen audiobestanden, geen licenties. */
enum class Sound(
    @StringRes val label: Int,
    val emoji: String,
    val free: Boolean,
    val factory: () -> Gen
) {
    RAIN(R.string.sound_rain, "🌧️", true, ::RainGen),
    BROWN(R.string.sound_brown, "🟤", true, { BrownGen() }),
    WHITE(R.string.sound_white, "⚪", true, ::WhiteGen),
    OCEAN(R.string.sound_ocean, "🌊", false, ::OceanGen),
    FIRE(R.string.sound_fire, "🔥", false, ::FireGen),
    WIND(R.string.sound_wind, "💨", false, ::WindGen),
    STREAM(R.string.sound_stream, "🏞️", false, ::StreamGen),
    FAN(R.string.sound_fan, "🌀", false, ::FanGen),
    PINK(R.string.sound_pink, "🌸", false, { PinkGen() })
}

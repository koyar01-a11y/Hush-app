package com.example.hush

import android.app.Activity
import android.content.Context
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.android.billingclient.api.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class Plan(val basePlanId: String, val price: String, val offerToken: String, val hasTrial: Boolean)

/**
 * Google Play-abonnement. Maak in de Play Console een abonnement met product-ID "hush_pro"
 * en twee base plans: "monthly" en "yearly" (optioneel met gratis proefperiode als aanbieding).
 */
class BillingManager(context: Context, private val scope: CoroutineScope) : PurchasesUpdatedListener {

    companion object {
        const val PRO_ID = "hush_pro"
    }

    private val prefs = context.getSharedPreferences("hush", Context.MODE_PRIVATE)

    private val _isPro = MutableStateFlow(prefs.getBoolean("pro", false))
    val isPro: StateFlow<Boolean> = _isPro.asStateFlow()

    private val _plans = MutableStateFlow<List<Plan>>(emptyList())
    val plans: StateFlow<List<Plan>> = _plans.asStateFlow()

    private var details: ProductDetails? = null

    private val client: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun start() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    scope.launch {
                        loadProduct()
                        refreshPurchases()
                    }
                }
            }

            override fun onBillingServiceDisconnected() {
                scope.launch {
                    delay(10_000)
                    start()
                }
            }
        })
    }

    private suspend fun loadProduct() {
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PRO_ID)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )
            ).build()
        val d = client.queryProductDetails(params).productDetailsList?.firstOrNull() ?: return
        details = d
        _plans.value = d.subscriptionOfferDetails.orEmpty()
            .groupBy { it.basePlanId }
            .map { (id, offers) ->
                val best = offers.maxByOrNull { it.pricingPhases.pricingPhaseList.size }!!
                val phases = best.pricingPhases.pricingPhaseList
                Plan(id, phases.last().formattedPrice, best.offerToken, phases.size > 1)
            }
            .sortedBy { if (it.basePlanId == "yearly") 0 else 1 }
    }

    private suspend fun refreshPurchases() {
        val result = client.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )
        if (result.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
            handle(result.purchasesList)
        }
    }

    fun launch(activity: Activity, plan: Plan) {
        val d = details ?: return
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(d)
                        .setOfferToken(plan.offerToken)
                        .build()
                )
            ).build()
        client.launchBillingFlow(activity, params)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            scope.launch { handle(purchases) }
        }
    }

    private suspend fun handle(purchases: List<Purchase>) {
        var pro = false
        for (p in purchases) {
            if (p.purchaseState == Purchase.PurchaseState.PURCHASED && p.products.contains(PRO_ID)) {
                pro = true
                if (!p.isAcknowledged) {
                    client.acknowledgePurchase(
                        AcknowledgePurchaseParams.newBuilder()
                            .setPurchaseToken(p.purchaseToken)
                            .build()
                    )
                }
            }
        }
        _isPro.value = pro
        prefs.edit().putBoolean("pro", pro).apply()
    }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val billing = BillingManager(app, viewModelScope).also { it.start() }
}

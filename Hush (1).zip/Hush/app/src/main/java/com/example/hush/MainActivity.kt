package com.example.hush

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private val HushColors = darkColorScheme(
    primary = Color(0xFF9CB8FF),
    onPrimary = Color(0xFF0B1020),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE8EEFF),
    surface = Color(0xFF151B34),
    onSurface = Color(0xFFE8EEFF),
    surfaceVariant = Color(0xFF1E2646),
    onSurfaceVariant = Color(0xFFB8C2E6),
    primaryContainer = Color(0xFF2B3A78),
    onPrimaryContainer = Color(0xFFE8EEFF)
)

private val TIMER_OPTIONS = listOf(0, 15, 30, 60, 120, 240, 480)
private const val FREE_TIMER_MAX = 60

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = HushColors) { HushApp() }
        }
    }
}

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun HushApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val levels by SoundEngine.levels.collectAsStateWithLifecycle()
    val playing by SoundEngine.playing.collectAsStateWithLifecycle()
    val timer by SoundEngine.timerMinutes.collectAsStateWithLifecycle()
    val remaining by SoundEngine.remainingSec.collectAsStateWithLifecycle()
    val isPro by vm.billing.isPro.collectAsStateWithLifecycle()
    val plans by vm.billing.plans.collectAsStateWithLifecycle()
    var showPaywall by remember { mutableStateOf(false) }

    LaunchedEffect(isPro) { if (isPro) showPaywall = false }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val ensurePlaying = {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
    }

    fun toggle(sound: Sound) {
        if (!sound.free && !isPro) { showPaywall = true; return }
        val on = (levels[sound] ?: 0f) > 0f
        if (on) {
            SoundEngine.setLevel(sound, 0f)
            if (SoundEngine.levels.value.values.none { it > 0f }) SoundEngine.stop(1f)
        } else {
            if (!isPro) Sound.entries.forEach { if (it != sound) SoundEngine.setLevel(it, 0f) }
            SoundEngine.setLevel(sound, 0.7f)
            ensurePlaying()
        }
    }

    fun togglePlayback() {
        if (playing) {
            SoundEngine.stop(1.2f)
        } else {
            if (SoundEngine.levels.value.values.none { it > 0f }) SoundEngine.setLevel(Sound.RAIN, 0.7f)
            ensurePlaying()
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (!isPro) {
                    TextButton(onClick = { showPaywall = true }) { Text(stringResource(R.string.go_pro)) }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(Sound.entries) { sound ->
                    SoundCard(
                        sound = sound,
                        level = levels[sound] ?: 0f,
                        locked = !sound.free && !isPro,
                        onToggle = { toggle(sound) },
                        onLevel = { SoundEngine.setLevel(sound, it) }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.timer_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                if (playing && timer > 0 && remaining > 0) {
                    Text(stringResource(R.string.stops_in, formatTime(remaining)))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TIMER_OPTIONS.forEach { min ->
                    val locked = min > FREE_TIMER_MAX && !isPro
                    TimerChip(
                        label = (if (locked) "🔒 " else "") + timerLabel(min),
                        selected = timer == min,
                        onClick = { if (locked) showPaywall = true else SoundEngine.setTimer(min) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { togglePlayback() },
                modifier = Modifier.fillMaxWidth().height(56.dp).padding(bottom = 0.dp)
            ) {
                Text(
                    (if (playing) "■  " else "▶  ") +
                        stringResource(if (playing) R.string.stop else R.string.play),
                    fontSize = 18.sp
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (showPaywall) {
        PaywallDialog(
            plans = plans,
            onBuy = { plan -> context.findActivity()?.let { vm.billing.launch(it, plan) } },
            onDismiss = { showPaywall = false }
        )
    }
}

@Composable
fun SoundCard(sound: Sound, level: Float, locked: Boolean, onToggle: () -> Unit, onLevel: (Float) -> Unit) {
    val active = level > 0f
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = if (active) cs.primaryContainer else cs.surface)
    ) {
        Column(Modifier.padding(16.dp).defaultMinSize(minHeight = 96.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sound.emoji, fontSize = 30.sp)
                Spacer(Modifier.weight(1f))
                if (locked) Text("🔒")
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(sound.label), fontWeight = FontWeight.Medium)
            if (active) {
                Slider(value = level, onValueChange = onLevel, valueRange = 0.05f..1f)
            }
        }
    }
}

@Composable
fun TimerChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(label, color = if (selected) cs.onPrimary else cs.onSurfaceVariant)
    }
}

@Composable
fun timerLabel(min: Int): String = when {
    min == 0 -> stringResource(R.string.timer_off)
    min % 60 == 0 -> stringResource(R.string.timer_hour, min / 60)
    else -> stringResource(R.string.timer_min, min)
}

fun formatTime(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
fun PaywallDialog(plans: List<Plan>, onBuy: (Plan) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.pro_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("✓ " + stringResource(R.string.pro_benefit_sounds))
                Text("✓ " + stringResource(R.string.pro_benefit_mix))
                Text("✓ " + stringResource(R.string.pro_benefit_timer))
                Spacer(Modifier.height(4.dp))
                if (plans.isEmpty()) Text(stringResource(R.string.pro_unavailable))
                plans.forEach { p ->
                    Button(onClick = { onBuy(p) }, modifier = Modifier.fillMaxWidth()) {
                        Text(planLabel(p))
                    }
                    if (p.hasTrial) Text(stringResource(R.string.plan_trial_hint), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.not_now)) } }
    )
}

@Composable
fun planLabel(p: Plan): String = when (p.basePlanId) {
    "yearly" -> stringResource(R.string.plan_yearly, p.price)
    "monthly" -> stringResource(R.string.plan_monthly, p.price)
    else -> p.price
}

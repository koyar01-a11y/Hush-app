# Privacy Policy – Hush

Last updated: [DATE]

Hush does not collect, store, or share any personal data. The app works fully offline and has no account, no analytics, no advertising and no tracking.

Purchases: If you subscribe to Hush Pro, the payment is processed entirely by Google Play. We do not receive your payment details. Google's privacy policy applies to that processing.

Permissions: Notifications (to show the playback controls while sounds play) and foreground playback (so sounds continue when the screen is off). Both are used only for this purpose.

Children: Hush does not knowingly collect data from anyone, including children.

Contact: [YOUR EMAIL]
